# RefindProyecto
Proyecto creado para la asignatura del proyecto de DAM2
Se trata de una APP de bsuqueda para servicios como (talleres, restaurantes...)
